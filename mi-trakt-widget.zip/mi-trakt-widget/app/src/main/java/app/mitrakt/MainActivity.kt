package app.mitrakt

import android.app.Activity
import android.os.Bundle
import android.util.Base64
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom

class MainActivity : Activity() {
    private lateinit var status: TextView

    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 80, 48, 48)
            setBackgroundColor(0xFF16131D.toInt())
        }
        fun label(t: String) = TextView(this).apply { text = t; setTextColor(0xFF9D96AC.toInt()); textSize = 12f; setPadding(0, 24, 0, 0) }
        fun field(v: String) = EditText(this).apply { setText(v); setTextColor(0xFFEFEBF5.toInt()); setSingleLine(true) }
        val title = TextView(this).apply { text = "Mi Trakt · Widget"; setTextColor(0xFFEFEBF5.toInt()); textSize = 24f }
        val cid = field(Prefs.cid(this))
        val tm = field(Prefs.tmdb(this))
        val web = field(Prefs.web(this))
        status = TextView(this).apply { setTextColor(0xFFFF6B9A.toInt()); textSize = 16f; setPadding(0, 32, 0, 32) }
        val btnConnect = Button(this).apply { text = "Conectar con Trakt" }
        val update = Button(this).apply { text = "Actualizar widget" }
        val help = TextView(this).apply {
            setTextColor(0xFF9D96AC.toInt()); textSize = 13f; setPadding(0, 32, 0, 0)
            text = "Después de conectar, mantén pulsada la pantalla de inicio, elige Widgets y añade «Mi Trakt»."
        }
        status.text = if (Prefs.connected(this)) "✓ Conectado a Trakt" else "Sin conexión con Trakt"
        btnConnect.setOnClickListener {
            Prefs.sp(this).edit().putString("cid", cid.text.toString().trim())
                .putString("tmdb", tm.text.toString().trim()).putString("web", web.text.toString().trim()).apply()
            connect()
        }
        update.setOnClickListener { refreshWidgets(this, true); status.text = "Widget actualizado" }
        listOf(title, label("Trakt Client ID"), cid, label("Clave TMDB (carátulas)"), tm,
            label("Dirección de tu app web"), web, status, btnConnect, update, help).forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun say(t: String) = runOnUiThread { status.text = t }

    private fun connect() {
        Thread {
            try {
                val ver = b64(ByteArray(64).also { SecureRandom().nextBytes(it) })
                val chal = b64(MessageDigest.getInstance("SHA-256").digest(ver.toByteArray()))
                val (code, text) = Trakt.raw(this, "/oauth/device/code",
                    JSONObject().put("client_id", Prefs.cid(this)).put("code_challenge", chal)
                        .put("code_challenge_method", "S256").toString(), false)
                if (code != 200) { say("Trakt rechazó el Client ID ($code)"); return@Thread }
                val d = JSONObject(text)
                say("Abre ${d.getString("verification_url")} e introduce el código:\n\n${d.getString("user_code")}")
                var interval = d.optInt("interval", 5)
                val end = System.currentTimeMillis() + d.getInt("expires_in") * 1000L
                while (System.currentTimeMillis() < end) {
                    Thread.sleep(interval * 1000L)
                    val (c2, t2) = Trakt.raw(this, "/oauth/device/token",
                        JSONObject().put("code", d.getString("device_code")).put("client_id", Prefs.cid(this))
                            .put("code_verifier", ver).toString(), false)
                    if (c2 == 200) {
                        val j = JSONObject(t2)
                        Prefs.sp(this).edit().putString("tok", j.getString("access_token"))
                            .putString("rt", j.optString("refresh_token")).apply()
                        refreshWidgets(this, true)
                        say("✓ Conectado a Trakt")
                        return@Thread
                    }
                    if (c2 == 429) interval += 2 else if (c2 != 400) { say("Conexión rechazada ($c2)"); return@Thread }
                }
                say("El código ha caducado. Inténtalo de nuevo.")
            } catch (e: Exception) { say("Error de red: ${e.message}") }
        }.start()
    }
}
