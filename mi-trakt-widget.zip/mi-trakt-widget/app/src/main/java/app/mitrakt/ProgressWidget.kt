package app.mitrakt

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.widget.RemoteViews
import android.widget.RemoteViewsService
import android.widget.Toast

class ProgressWidget : AppWidgetProvider() {
    companion object {
        const val ACT_SEEN = "app.mitrakt.SEEN"
        const val ACT_VER = "app.mitrakt.VER"
        const val ACT_REFRESH = "app.mitrakt.REFRESH"
    }

    override fun onUpdate(ctx: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) m.updateAppWidget(id, views(ctx, id))
        m.notifyAppWidgetViewDataChanged(ids, R.id.list)
    }

    private fun views(ctx: Context, id: Int): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_progress)
        val svc = Intent(ctx, WidgetService::class.java).apply {
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            data = Uri.parse(toUri(Intent.URI_INTENT_SCHEME))
        }
        rv.setRemoteAdapter(R.id.list, svc)
        rv.setEmptyView(R.id.list, R.id.empty)
        val tpl = PendingIntent.getBroadcast(ctx, 0, Intent(ctx, ProgressWidget::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
        rv.setPendingIntentTemplate(R.id.list, tpl)
        val ref = PendingIntent.getBroadcast(ctx, 1, Intent(ctx, ProgressWidget::class.java).setAction(ACT_REFRESH),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        rv.setOnClickPendingIntent(R.id.refresh, ref)
        return rv
    }

    override fun onReceive(ctx: Context, i: Intent) {
        super.onReceive(ctx, i)
        when (i.action) {
            ACT_SEEN -> {
                val ep = i.getIntExtra("ep", 0)
                Progress.hide(ctx, ep)               // se oculta al instante
                refreshWidgets(ctx, false)
                val pr = goAsync()
                Thread {
                    try { Progress.markSeen(ctx, ep) }
                    catch (e: Exception) {
                        Handler(Looper.getMainLooper()).post {
                            Toast.makeText(ctx, "No se pudo marcar como visto", Toast.LENGTH_LONG).show()
                        }
                        refreshWidgets(ctx, true)
                    }
                    pr.finish()
                }.start()
            }
            ACT_VER -> {
                val u = i.getStringExtra("url") ?: return
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            ACT_REFRESH -> refreshWidgets(ctx, true)
        }
    }
}

class WidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory = Factory(applicationContext)
}

class Factory(private val c: Context) : RemoteViewsService.RemoteViewsFactory {
    private var items: List<Item> = emptyList()

    override fun onCreate() {}
    override fun onDestroy() {}
    override fun onDataSetChanged() {
        items = try { Progress.load(c) } catch (e: Exception) { Progress.cached(c) }
    }

    override fun getCount() = items.size
    override fun getLoadingView(): RemoteViews? = null
    override fun getViewTypeCount() = 1
    override fun getItemId(position: Int) = items[position].epId.toLong()
    override fun hasStableIds() = true

    override fun getViewAt(position: Int): RemoteViews {
        val it = items[position]
        val rv = RemoteViews(c.packageName, R.layout.widget_item)
        rv.setTextViewText(R.id.title, it.title)
        rv.setTextViewText(R.id.ep, "T%02d | E%02d".format(it.season, it.number) + if (it.epTitle.isNotEmpty()) " · ${it.epTitle}" else "")
        rv.setTextViewText(R.id.date, fmtDate(it.air))
        Poster.get(c, it.tmdb)?.let { b -> rv.setImageViewBitmap(R.id.poster, b) }
        rv.setOnClickFillInIntent(R.id.btnSeen, Intent().setAction(ProgressWidget.ACT_SEEN).putExtra("ep", it.epId))
        val url = Prefs.web(c) + "#ver=${it.showId}:${it.epId}:${it.season}:${it.number}:${it.tmdb}"
        rv.setOnClickFillInIntent(R.id.btnVer, Intent().setAction(ProgressWidget.ACT_VER).putExtra("url", url))
        return rv
    }
}
