package app.mitrakt

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

object Prefs {
    const val DEF_CID = "2dFp8k9VZWx3_XvbbQM06P1QBG9TcB-LGik30OrzWuQ"
    const val DEF_TMDB = "1ecd17043eeaf60425225d378af33c0a"
    const val DEF_WEB = "https://fgmorte.github.io/mi-trakt/"
    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("mt", Context.MODE_PRIVATE)
    fun cid(c: Context) = sp(c).getString("cid", DEF_CID) ?: DEF_CID
    fun tmdb(c: Context) = sp(c).getString("tmdb", DEF_TMDB) ?: DEF_TMDB
    fun web(c: Context) = sp(c).getString("web", DEF_WEB) ?: DEF_WEB
    fun connected(c: Context) = !sp(c).getString("tok", "").isNullOrEmpty()
}

object Trakt {
    private const val API = "https://api.trakt.tv"

    /** Llamada cruda: devuelve (código HTTP, cuerpo). */
    fun raw(c: Context, path: String, body: String? = null, auth: Boolean = true): Pair<Int, String> {
        val sp = Prefs.sp(c)
        val con = URL(API + path).openConnection() as HttpURLConnection
        con.requestMethod = if (body != null) "POST" else "GET"
        con.connectTimeout = 15000
        con.readTimeout = 25000
        con.setRequestProperty("Content-Type", "application/json")
        con.setRequestProperty("trakt-api-version", "2")
        con.setRequestProperty("trakt-api-key", Prefs.cid(c))
        val tok = sp.getString("tok", "") ?: ""
        if (auth && tok.isNotEmpty()) con.setRequestProperty("Authorization", "Bearer $tok")
        if (body != null) {
            con.doOutput = true
            con.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = con.responseCode
        val stream = if (code in 200..299) con.inputStream else con.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        return Pair(code, text)
    }

    fun call(c: Context, path: String, body: String? = null, retry: Boolean = true): String {
        val (code, text) = raw(c, path, body)
        if (code == 401 && retry && refresh(c)) return call(c, path, body, false)
        if (code !in 200..299) throw java.io.IOException("HTTP $code")
        return text
    }

    private fun refresh(c: Context): Boolean {
        val sp = Prefs.sp(c)
        val rt = sp.getString("rt", "") ?: ""
        if (rt.isEmpty()) return false
        return try {
            val b = JSONObject().put("refresh_token", rt).put("client_id", Prefs.cid(c))
                .put("redirect_uri", "http://localhost").put("grant_type", "refresh_token")
            val (code, text) = raw(c, "/oauth/token", b.toString(), false)
            if (code != 200) return false
            val j = JSONObject(text)
            sp.edit().putString("tok", j.getString("access_token")).putString("rt", j.optString("refresh_token", rt)).apply()
            true
        } catch (e: Exception) { false }
    }

    fun plain(url: String): String = URL(url).openConnection().let { con ->
        con.connectTimeout = 15000; con.readTimeout = 20000
        con.getInputStream().bufferedReader().use { it.readText() }
    }
}

data class Item(
    val showId: Int, val epId: Int, val title: String, val season: Int,
    val number: Int, val epTitle: String, val air: String, val tmdb: Int
)

object Progress {
    private fun toJson(l: List<Item>): String {
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("s", it.showId).put("e", it.epId).put("t", it.title).put("se", it.season)
                .put("n", it.number).put("et", it.epTitle).put("a", it.air).put("m", it.tmdb))
        }
        return a.toString()
    }

    fun cached(c: Context): List<Item> = try {
        val a = JSONArray(Prefs.sp(c).getString("list", "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Item(o.getInt("s"), o.getInt("e"), o.getString("t"), o.getInt("se"), o.getInt("n"),
                o.optString("et"), o.optString("a"), o.optInt("m"))
        }
    } catch (e: Exception) { emptyList() }

    fun save(c: Context, l: List<Item>, touch: Boolean) {
        val ed = Prefs.sp(c).edit().putString("list", toJson(l))
        if (touch) ed.putLong("ts", System.currentTimeMillis())
        ed.apply()
    }

    /** Series empezadas con episodios pendientes (las 12 más recientes). */
    fun load(c: Context): List<Item> {
        val sp = Prefs.sp(c)
        if (!Prefs.connected(c)) return emptyList()
        if (System.currentTimeMillis() - sp.getLong("ts", 0) < 600_000 && sp.contains("list")) return cached(c)
        val w = JSONArray(Trakt.call(c, "/sync/watched/shows?extended=noseasons"))
        val shows = (0 until w.length()).map { w.getJSONObject(it) }
            .sortedByDescending { it.optString("last_watched_at") }.take(30)
        val out = ArrayList<Item>()
        for (o in shows) {
            if (out.size >= 12) break
            val show = o.getJSONObject("show")
            val ids = show.getJSONObject("ids")
            val id = ids.getInt("trakt")
            val p = try { JSONObject(Trakt.call(c, "/shows/$id/progress/watched")) } catch (e: Exception) { continue }
            val ne = p.optJSONObject("next_episode") ?: continue
            if (p.optInt("completed") >= p.optInt("aired")) continue
            val s = ne.getInt("season")
            val n = ne.getInt("number")
            val air = try {
                JSONObject(Trakt.call(c, "/shows/$id/seasons/$s/episodes/$n?extended=full")).optString("first_aired")
            } catch (e: Exception) { "" }
            out.add(Item(id, ne.getJSONObject("ids").getInt("trakt"), show.getString("title"), s, n,
                ne.optString("title").let { if (it == "null") "" else it },
                if (air == "null") "" else air, ids.optInt("tmdb")))
        }
        save(c, out, true)
        return out
    }

    fun hide(c: Context, epId: Int) = save(c, cached(c).filter { it.epId != epId }, false)

    fun markSeen(c: Context, epId: Int) {
        Trakt.call(c, "/sync/history", """{"episodes":[{"ids":{"trakt":$epId}}]}""")
    }
}

object Poster {
    fun get(c: Context, tmdb: Int): Bitmap? {
        if (tmdb == 0) return null
        val f = File(c.cacheDir, "p$tmdb.jpg")
        if (f.exists()) return BitmapFactory.decodeFile(f.path)
        return try {
            val j = JSONObject(Trakt.plain("https://api.themoviedb.org/3/tv/$tmdb?api_key=${Prefs.tmdb(c)}"))
            val pp = j.optString("poster_path")
            if (pp.isEmpty() || pp == "null") return null
            val bytes = URL("https://image.tmdb.org/t/p/w154$pp").readBytes()
            f.writeBytes(bytes)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (e: Exception) { null }
    }
}

fun fmtDate(iso: String): String = try {
    val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
    val d = f.parse(iso.take(19))!!
    "Estreno: " + SimpleDateFormat("d MMM yyyy", Locale("es")).format(d)
} catch (e: Exception) { "" }

fun refreshWidgets(c: Context, force: Boolean) {
    if (force) Prefs.sp(c).edit().remove("ts").apply()
    val m = AppWidgetManager.getInstance(c)
    val ids = m.getAppWidgetIds(ComponentName(c, ProgressWidget::class.java))
    m.notifyAppWidgetViewDataChanged(ids, R.id.list)
}
